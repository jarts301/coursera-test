class MenuItem < ActiveRecord::Base
 	belongs_to :category
end
