# Restaurant

Restaurant front-end implementation in AngularJS for David Chu's China Bistro.

Enroll in the [complete free course on AngularJS][aeac87f1]
  [aeac87f1]: https://www.coursera.org/learn/single-page-web-apps-with-angularjs "AngularJS course"

  [Single Page Web Applications with AngularJS][39804538]
  [39804538]: https://www.coursera.org/learn/single-page-web-apps-with-angularjs "Enroll in the course on AngluarJS"
